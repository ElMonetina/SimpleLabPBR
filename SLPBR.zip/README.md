SimpleLabPBR is a very minimal resource pack for Minecraft Java Edition. It provides textures for shaders to apply a number of effects following the LabPBR Material Standard

The RP is in a very early stage and i will be able to work on it only in my free time, therefore progression speed may vary.

![2024-04-22_18 03 17](https://github.com/ElMonetina/SimpleLabPBR/assets/79310913/a20de347-b5b1-4268-bb5a-55af765da0e9)

![2024-04-22_18 02 39](https://github.com/ElMonetina/SimpleLabPBR/assets/79310913/b3d979a9-cfd6-4aca-8925-81e33b40b719)

SimpleLabPBR started as a personal project, but I quickly decided to make it public and free, which it will always remain.
